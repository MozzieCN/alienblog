<?php 
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
} ?>

<li><a href="http://www.loveapple.cc/" rel="external">恋上苹果</a></li>
<li><a href="http://imlg.tk/" rel="external">tolbKni</a></li>
<li><a href="http://www.ading123.com/" rel="external">阿鼎小窝</a></li>