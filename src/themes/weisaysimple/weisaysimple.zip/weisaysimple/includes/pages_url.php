<div class="page_menu">
<ul id="menu-pages-menu" class="navi">
<li class="page_item page-item-0"><a href="<?php echo get_settings('Home'); ?>/" title="首页">首页</a></li>
<?php wp_list_pages('depth=2&title_li='); ?>
</ul></div>